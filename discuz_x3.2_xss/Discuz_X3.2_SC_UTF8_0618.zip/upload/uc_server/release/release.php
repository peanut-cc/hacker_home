<?php

if(!defined('UC_SERVER_VERSION')) {
	define('UC_SERVER_VERSION', '1.6.0');
	define('UC_SERVER_RELEASE', '20110501');
}

?>