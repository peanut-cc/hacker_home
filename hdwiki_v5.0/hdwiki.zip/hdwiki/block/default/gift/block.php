<?php

$block['name']='礼品商店';
$block['description'] = '可供兑换的礼品列表。';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-6-29';
$block['fun'] = array(
	'giftlist'=>'礼品列表',
	'giftpricerange'=>'礼品价格范围',
	'giftnotice'=>'礼品公告'
);
?>