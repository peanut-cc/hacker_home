<?php
$block['name']='百科图片';
$block['description']='本版块包含对于所有和图片相关的调用。';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-06-04';
$block['fun'] = array(
	'recentpics'=>'最新图片'
);