<?php
$block['name']='公告&动态';
$block['description']='本版块包含站内公告和最新动态';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-06-04';
$block['fun'] = array(
	'recentnews'=>'最新动态&站内公告'
);