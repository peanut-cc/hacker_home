<?php
$block['name']='词条分类';
$block['description'] = '展示词条分类';
$block['author']='互动百科';
$block['version']='5.0';
$block['time']='2010-7-30';
$block['fun'] = array(
	'viewcategory'=>'展示分类'
);
?>