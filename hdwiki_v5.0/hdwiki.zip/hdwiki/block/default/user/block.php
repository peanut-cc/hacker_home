<?php
$block['name']='用户';
$block['description']='本版块包含对于所有和用户相关的调用。';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-06-04';
$block['fun'] = array(
	'login'=>'用户登录'
);