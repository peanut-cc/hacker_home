<?php  foreach ( $sidebar3 as $module) { ?> 
<?php  include $this->GetTemplate('module');  ?>
<?php  }   ?>