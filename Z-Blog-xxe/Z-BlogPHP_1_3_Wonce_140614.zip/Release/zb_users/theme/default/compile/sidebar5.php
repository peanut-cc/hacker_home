<?php  foreach ( $sidebar5 as $module) { ?> 
<?php  include $this->GetTemplate('module');  ?>
<?php  }   ?>