<footer>
  <h4><?php  echo $copyright;  ?></h4>
  <h5>Powered By <?php  echo $zblogphphtml;  ?></h5>
</footer>
<?php  echo $footer;  ?>
</body>
</html>