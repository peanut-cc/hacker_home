<footer>
  <h4>{$copyright}</h4>
  <h5>Powered By {$zblogphphtml}</h5>
</footer>
{$footer}
</body>
</html>