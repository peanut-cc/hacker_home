<div id="footer">
  <div class="copyright">
    <p>Powered By <?php  echo $zblogphphtml;  ?></p>
    <p><?php  echo $copyright;  ?></p>
  </div>
  <div id="goTopBtn">
    <a onclick="pageScroll()"><span>返回顶部</span></a>
  </div>
  <div class="clear"></div>
</div>
<?php  echo $footer;  ?>
</body>
</html>