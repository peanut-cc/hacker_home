 <div class="istop-post postistop post cate<?php  echo $article->Category->ID;  ?>  auth<?php  echo $article->Author->ID;  ?>">
	<div class="post_time"></div>
	<div class="post_r">
		<div class="post_body">
		<h2><a href="<?php  echo $article->Url;  ?>" title="<?php  echo $article->Title;  ?>"><?php  echo $article->Title;  ?></a></h2>
		</div>
	</div>
	<div class="clear"></div>
</div>