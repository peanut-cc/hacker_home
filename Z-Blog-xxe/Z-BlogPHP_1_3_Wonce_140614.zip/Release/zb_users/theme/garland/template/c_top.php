<!-- Layout -->
<div id="header-region" class="clear-block"></div>
    <div id="wrapper">
    <div id="container" class="clear-block">
      <div id="header">
        <div id="logo-floater">
        <h1><a href="{$host}" title="{$name}"><img src="{$host}zb_users/theme/{$theme}/style/{$style}/logo.png" alt="{$name}" id="logo"><span>{$name}</span></a></h1>
		 </div>
        <ul id="divNavBar" class="links primary-links">{module:navbar}</ul> 
      </div> <!-- /header -->
	  <div id="center"><div id="squeeze"><div class="right-corner"><div class="left-corner">
