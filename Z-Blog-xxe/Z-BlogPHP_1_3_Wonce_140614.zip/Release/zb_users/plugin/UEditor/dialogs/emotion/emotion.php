<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="noindex, nofollow"/>
    <script type="text/javascript" src="../internal.js"></script>
    <link rel="stylesheet" type="text/css" href="emotion.css">
</head>
<body>

<div id="tabPanel" class="wrapper">
    <div id="tabHeads" class="tabhead">
    </div>
    <div id="tabBodys" class="tabbody">
    </div>
</div>

<div id="tabIconReview">
    <img id='faceReview' class='review'/>
</div>
<script type="text/javascript" src="../internal.js"></script>
<script type="text/javascript" src="emotion.js.php"  charset="utf-8"></script>
<script type="text/javascript">
    var emotion = {
        tabNum:0, //切换面板数量
        SmilmgName:{}, //图片前缀名=>改为图片后缀名与图片数量
        imageFolders:{}, //图片对应文件夹路径
        imageCss:{}, //图片css类名
        imageCssOffset:{}, //图片偏移（图片大小）
        SmileyInfor:{
        }
    };
</script>
</body>
</html>